import axios from "axios";
import React from "react";
import styled from "styled-components";
import { useState ,useEffect} from "react";


 let Div = styled.div`
        .nav {
            margin-top: 2.666667vw;
    width: 100vw;
    height: 14.117647vw;
    // background-color: firebrick;
    font-size: 3.2vw;
     display: flex;
    //  justify-content: space-between; 
    // position: relative;

    padding-bottom:4vw; 

  }
  


.b_list {
    padding:0 2.66667vw;
    height: 20vw;
    // width: 100%;
    box-sizing: border-box;
    display: flex;
    flex-direction: row;
    overflow: auto;
        display: flex; 
         white-space: nowrap; 
}
.b_list::-webkit-scrollbar { 
  display: none; 
} 
.imgdd{
    border: 1px solid;
}
.b_item {
    width: 20vw;
    height: 20vw;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
    // background-color: rgb(173, 255, 224);
}

.b_list .b_item img {
    width: 13.33333vw;
    height: 13.33333vw;
    background-color: red;
    // color: red;
}



.b_list .b_item p {
    margin: 0;
    padding: 0;
    width: 40vw;
    text-align: center;
    font-size: 3.2vw;
}



 `


function Iconame(){

let [list,setList]= useState()

    useEffect(()=>{

        axios.get(
            "https://netease-cloud-music-api-five-roan-88.vercel.app/homepage/dragon/ball"
            ).then((res)=>{
                console.log(res.data.data);
                setList(res.data.data)
            })

    },[])


    return <Div>
      <div class="nav">
        <div class="b_list">
            {list && list.map((item)=>(
                 <div class="b_item">
                 <div class="imgdd">
                   <img src={item.iconUrl} alt=""/>
                   </div>
                   <p>{item.name}</p>
   
               </div>
            ))}
        </div>
        </div>
    </Div>

}


export default Iconame
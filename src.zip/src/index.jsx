import React from "react";
import ReactDOM from "react-dom/client";
import "./main.css"
import styled from "styled-components";
import Home from "./Home.jsx";



const root = ReactDOM.createRoot(document.getElementById("root"))
root.render(
    <>

    
     <Home></Home> 




   
</>
 )

